namespace WebApi.Entities;

public enum Role
{
    Admin,
    User
}